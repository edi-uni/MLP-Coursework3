import numpy as np
import scipy as sp
import pandas as pd
import random
import time
import matplotlib.pyplot as plt
import math

from sklearn.ensemble import RandomForestClassifier
#from sklearn.cross_validation import KFold   #from sklearn.model_selection import KFold

from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import mean_squared_error

from keras import layers
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras.models import load_model



# RANDOM FOREST
# best_n: 100
# best_m: 10
#
# Mean Absolute Train Error: 0.3 degrees.
# Train Accuracy: 70.18 %.
# Mean Absolute Test Error: 0.33 degrees.
# Test Accuracy: 67.08 %.

# LOGISTIC REGRESSION
# solver = liblinear
# Mean Absolute Train Error: 0.32 degrees.
# Train Accuracy: 68.32 %.
# Mean Absolute Test Error: 0.32 degrees.
# Test Accuracy: 67.81 %.
# solver = lbfgs
# Mean Absolute Train Error: 0.32 degrees.
# Train Accuracy: 67.83 %.
# Mean Absolute Test Error: 0.33 degrees.
# Test Accuracy: 66.67 %.

# NAIVE BAYES
# Mean Absolute Train Error: 0.38 degrees.
# Train Accuracy: 62.46 %.
# Mean Absolute Test Error: 0.37 degrees.
# Test Accuracy: 63.06 %.


filename= "data.csv"
# raw = pd.read_csv(filename)

shot_zone_area_dict = {'Center(C)': 1, 'Left Side(L)': 4, 'Right Side(R)': 4, 'Left Side Center(LC)': 7, 'Right Side Center(RC)': 7, 'Back Court(BC)': 10}

def process_data():
    raw = pd.read_csv(filename)
    # drops = ['shot_id', 'team_id', 'team_name', 'shot_zone_area', 'shot_zone_range', 'shot_zone_basic', \
             # 'matchup', 'game_event_id', 'game_id', 'game_date']
    # drops = ['team_id', 'team_name', 'matchup', 'game_id', 'game_date']
    drops = ['team_id', 'team_name', 'game_event_id', 'game_id', 'game_date', 'shot_id']
    for drop in drops:
        raw = raw.drop(drop, 1)

    # categorical_vars = ['action_type', 'combined_shot_type', 'shot_type', 'opponent', 'season']
    # categorical_vars = ['action_type', 'combined_shot_type', 'shot_type', 'opponent', 'season', 'shot_id', 'shot_zone_area', 'shot_zone_range', 'shot_zone_basic', \
    #          'matchup', 'game_event_id', 'game_date']
    categorical_vars = ['action_type', 'combined_shot_type', 'shot_type', 'shot_zone_area', 'shot_zone_range', 'shot_zone_basic', 'opponent', 'season']
    for var in categorical_vars:
        raw = pd.concat([raw, pd.get_dummies(raw[var], prefix=var)], 1)
        raw = raw.drop(var, 1)

    for i, row in enumerate(raw.itertuples(), 1):
        if "@" in row.matchup:
            raw.set_value(row.Index, 'matchup', 0)
        else:
            raw.set_value(row.Index, 'matchup', 1)

    df = raw[pd.notnull(raw['shot_made_flag'])]
    indexOfNull = raw[raw['shot_made_flag'].isnull()].index.tolist()

    return raw, df, indexOfNull


def split_data(raw, df, indexOfNull):
    per_test =  round((15 * len(df))/100)
    n =[0 for i in range(per_test)]

    m = len(indexOfNull)-1
    for z in range(per_test):
        c = indexOfNull[m]+1
        x = raw.iloc[c]
        #print(pd.notnull(x['shot_made_flag']))
        flg = 0
        if(pd.isnull(x['shot_made_flag'])):
            #print(c)
            flg =1
            while flg==1:
                c = c+1
                x = raw.iloc[c]
                if pd.notnull(x['shot_made_flag']):
                    flg =0
        n[z] = c
        m=m-1;



    test_comp = raw.iloc[n]
    test = test_comp.drop('shot_made_flag', 1)
    test_y = test_comp['shot_made_flag']
    df = raw.drop(raw.index[n])
    df= df[pd.notnull(df['shot_made_flag'])]
    # separate df into explanatory and response variables
    train = df.drop('shot_made_flag', 1)
    train_y = df['shot_made_flag']
    #print(train,train_y,test,test_y)
    return train, train_y, test, test_y

def rnn(train, train_y, test,test_y):
    look_back = 4
    RNN = layers.LSTM
    model = Sequential()
    train = train.to_numpy()
    num_batches = 100
    train_data = int(train.shape[0]/num_batches)
    train = train.reshape(1,train.shape[0],train.shape[1])

    train_y = train_y.to_numpy()
    train_y = train_y.reshape(num_batches,int(train_y.shape[0]/num_batches),1)

    model.add(RNN(train.shape[2], input_shape=(train.shape[1],train.shape[2]),return_sequences=True, activation='tanh'))
    model.add(Dense(activation="softmax", units=1))
    model.compile(loss='mean_squared_error', optimizer='adam',metrics = ['accuracy'])
    model.fit(train, train_y, epochs=10, batch_size=100, verbose=1)
    model.save('model.h5')
    # make predictions
    trainPredict = model.predict_classes(train)
    # calculate root mean squared error
    trainScore = math.sqrt(mean_squared_error(train_y.reshape(train_y.shape[1],train_y.shape[2]), trainPredict.reshape(trainPredict.shape[1],trainPredict.shape[2])))
    print('Train Score: %.2f RMSE' % (trainScore))
    loss_and_metrics = model.evaluate(train, train_y, verbose=0)
    print("The loss and accuracy are ",loss_and_metrics)
    #return loss_and_metrics

def run_rnn(train, train_y, test,test_y):
    rnn(train, train_y, test,test_y)
    model = load_model('model.h5')
    test_y = test_y.to_numpy()
    test_y = test_y.reshape(1,test_y.shape[0],1)
    test = test.to_numpy()
    test = test.reshape(1,test.shape[0],test.shape[1])
    testPredict = model.predict_classes(test)
    # calculate root mean squared error
    testScore = math.sqrt(mean_squared_error(test_y.reshape(test_y.shape[1],test_y.shape[2]), testPredict.reshape(testPredict.shape[1],testPredict.shape[2])))
    print('Test Root mean square error: %.2f RMSE' % (testScore))
    loss_and_metrics = model.evaluate(test, test_y, verbose=0)
    print("The loss and accuracy on test set are ",loss_and_metrics)
    return loss_and_metrics


'''
MAIN
'''
if __name__ == '__main__':
    raw, df, indexOfNull = process_data()
    train, train_y, test, test_y = split_data(raw, df, indexOfNull)
    # best_n, best_m = find_RandomForest_parameters(train)
    # pred_train, pred_test = run_RandomForest(train, train_y, test, best_n, best_m)
    # pred_train, pred_test = run_LogisticRegression(train, train_y, test)
    #pred_train, pred_test = run_NaiveBayes(train, train_y, test)
    loss_and_metrics = run_rnn(train, train_y, test,test_y)
    #predictions_result(pred_train, train_y, pred_test, test_y)

