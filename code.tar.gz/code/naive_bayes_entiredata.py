# LSTM for international airline passengers problem with window regression framing
import numpy
import matplotlib.pyplot as plt
from pandas import read_csv
import math
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import pandas as pd
import kobe_bryant_classifier as kb
from sklearn.decomposition import PCA
from sklearn.naive_bayes import BernoulliNB
from sklearn.metrics import accuracy_score

filename= "data.csv"
raw = pd.read_csv(filename)
#seasons_dict, seasons_loc_dict, seasons_mode_dict = kb.split_for_experiments(raw)
#seasons_blocks_dict = kb.split_in_blocks(seasons_dict, 'season')
all_points = kb.get_all_testing_points(raw)
shot_zone_area_dict = {'Center(C)': 1, 'Left Side(L)': 4, 'Right Side(R)': 4, 'Left Side Center(LC)': 7, 'Right Side Center(RC)': 7, 'Back Court(BC)': 10}

# convert an array of values into a dataset matrix
def create_dataset(dataset, look_back):
	dataX, dataY = [], []
	train, train_y, test, test_y = kb.split_data(raw, all_points)
	pca = PCA(n_components=look_back)
	pc_train_1 = pca.fit_transform(train)
	pc_train = pd.DataFrame(data = pc_train_1)
	dataX = pc_train_1
	dataY = train_y.to_numpy()
	return numpy.array(dataX), numpy.array(dataY)

def create_dataset_test(dataset, look_back):
	dataX, dataY = [], []
	train, train_y, test, test_y = kb.split_data(raw, all_points)
	pca = PCA(n_components=look_back)
	pc_test_1 = pca.fit_transform(test)
	pc_test = pd.DataFrame(data = pc_test_1)
	dataX = pc_test
	dataY = test_y.to_numpy()
	return numpy.array(dataX), numpy.array(dataY)
# fix random seed for reproducibility
numpy.random.seed(7)
# load the dataset
#dataframe = read_csv('data.csv', usecols=[1], engine='python', skipfooter=3)
raw,unsorted_raw = kb.process_data()
#train, train_y, test, test_y = kb.split_data(raw,unsorted_raw)

# split into train and test sets

#train, test = dataset[0:train_size,:], dataset[train_size:len(dataset),:]
train, train_y, test, test_y = kb.split_data(raw, all_points)
train_size = int(len(train))
test_size = len(test) 

# reshape into X=t and Y=t+1
look_back = train.shape[1]
lb = look_back -1 
for i in range(lb):
	i = i+1
	print("The output dimentionality is",i)
	trainX, trainY = create_dataset(train, i)
	testX, testY = create_dataset_test(test, i)

	bnb = BernoulliNB(alpha=1.0, binarize=0.0, class_prior=None, fit_prior=True)
	bnb.fit(trainX, trainY)
# make predictions
	trainPredict = bnb.predict(trainX)
	accuracy_train = accuracy_score(trainY, trainPredict, normalize=True, sample_weight=None)
	print("The train accuracy is",accuracy_train)
	testPredict = bnb.predict(testX)
	accuracy = accuracy_score(testY, testPredict, normalize=True, sample_weight=None)
	print("The test accuracy is",accuracy)


#Plotting the accuracy of the neural network
plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('Accuracy of the RNN')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['Train', 'Test'], loc='upper left')
plt.show()
# "Loss"
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('RNN Loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Train', 'Test'], loc='upper left')
plt.show()

